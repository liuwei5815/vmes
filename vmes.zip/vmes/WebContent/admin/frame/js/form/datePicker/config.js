var langList = 
[
	{name:'en',	charset:'UTF-8'},
	{name:'zh-cn',	charset:'gb2312'},
	{name:'zh-tw',	charset:'GBK'}
];

var skinList = 
[
	{name:'green',	charset:'gb2312'},
	{name:'blue',	charset:'gb2312'},
	{name:'red',	charset:'gb2312'},
	{name:'yellowGreen',	charset:'UTF-8'},
	{name:'darkBlue',	charset:'gb2312'},
	{name:'darkYellow',	charset:'gb2312'},
	{name:'lightBlue',	charset:'UTF-8'},
	{name:'grayBlue',	charset:'UTF-8'}
];