package com.xy.cms.service.imp;

import com.xy.cms.common.base.BaseDAO;
import com.xy.cms.service.PeopleService;

public class PeopleServiceImpl extends BaseDAO implements PeopleService{

}
