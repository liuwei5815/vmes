package com.xy.cms.service;

public interface ICacheService {
	
	public void init() throws Exception;
	
	public void destroy();
}
