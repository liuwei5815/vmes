package com.xy.cms.service;

public interface PeopleService {

}
