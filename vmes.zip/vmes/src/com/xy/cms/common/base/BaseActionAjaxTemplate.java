package com.xy.cms.common.base;


public interface BaseActionAjaxTemplate {

	public Object execute() throws Exception;

}
