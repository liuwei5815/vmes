package com.xy.cms.db;

import com.xy.cms.db.bean.Where;

public interface WhereUtil {
	String getWhere(Where where);
}
